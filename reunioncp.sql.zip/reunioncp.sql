-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 16, 2025 at 12:17 PM
-- Server version: 8.0.30
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reunioncp`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `category_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--

CREATE TABLE `blog_categories` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `del_status` enum('Live','Disable') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Live',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_categories`
--

INSERT INTO `blog_categories` (`id`, `name`, `status`, `del_status`, `created_at`, `updated_at`) VALUES
(1, 'গুরুত্বপূর্ণ', '1', 'Live', '2025-07-16 02:53:58', '2025-07-16 02:55:01'),
(2, 'তথ্য', '1', 'Live', '2025-07-16 02:55:33', '2025-07-16 02:55:33'),
(3, 'স্থান', '1', 'Live', '2025-07-16 02:56:05', '2025-07-16 02:56:05');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2025_07_09_043319_create_registrations_table', 1),
(5, '2025_07_09_050428_create_payments_table', 1),
(6, '2025_07_09_050819_create_tokens_table', 1),
(7, '2025_07_16_062106_create_blogs_table', 2),
(8, '2025_07_16_062740_create_blog_categories_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` bigint UNSIGNED NOT NULL,
  `registration_id` bigint UNSIGNED NOT NULL,
  `method` enum('bkash') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `paid_from` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `registrations`
--

CREATE TABLE `registrations` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` year NOT NULL,
  `father_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blood` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tshirt` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profession` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `present_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `permanent_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `representative_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registration_type` enum('single','group') COLLATE utf8mb4_unicode_ci NOT NULL,
  `participant_count` int NOT NULL DEFAULT '1',
  `terms_agreed` tinyint(1) NOT NULL DEFAULT '0',
  `amount` decimal(10,2) NOT NULL,
  `bkash_num` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bkash_trans_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` enum('bkash Agent','bkash personal') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('painding','Approved','Cancel') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `registrations`
--

INSERT INTO `registrations` (`id`, `name`, `batch`, `father_name`, `blood`, `photo`, `tshirt`, `phone`, `email`, `profession`, `present_address`, `permanent_address`, `representative_name`, `registration_type`, `participant_count`, `terms_agreed`, `amount`, `bkash_num`, `bkash_trans_id`, `payment_method`, `status`, `created_at`, `updated_at`) VALUES
(1, 'মি. ইমরুল তাসনীম', 2005, 'হাসান খান', 'A-', 'photos/2.jpg', 'M', '01906050342', 'tabasasuma.barakata@example.com', 'সরকারি চাকরিজীবী', '৬ বরকত তলী, উত্তরখানা সিলেট', '৪৭ বরকত চিপা, দক্ষিনহাট খুলনা', NULL, 'single', 3, 1, '1720.97', '01974676001', 'IS19HU68', 'bkash personal', 'Approved', '2025-07-16 04:30:39', '2025-07-16 04:30:39'),
(2, 'রহিমা খান', 2020, 'আব্দুল্লাহ তাসনীম', 'A-', 'photos/1.jpg', 'L', '01571388563', 'tabasasuma.jalila@example.com', 'ডাক্তার', '৩৬ হাজী তলী, লেইকতলা কুমিল্লা', '৪৮ বরকত ক্যাম্প, লেইকহাট খুলনা', 'মাসনুন শিকদার', 'single', 3, 1, '989.68', '01928346016', 'QW90DW06', 'bkash personal', 'Approved', '2025-07-16 04:30:39', '2025-07-16 04:30:39'),
(3, 'মি. হাসনাত শিকদার', 2022, 'মি. রহিম শিকদার', 'A-', 'photos/1.jpg', 'L', '01837603646', 'wtabasasuma@example.com', 'ডাক্তার', '৫৭ করিমউদ্দিন সড়ক, পোর্টখানা ঢাকা', '৭০ হাজী তলী, পূর্বতলা সিলেট', 'ফারহানা শেখ', 'single', 1, 1, '560.11', '01512472164', 'AP33LJ77', 'bkash personal', 'Approved', '2025-07-16 04:30:39', '2025-07-16 04:30:39'),
(4, 'সাবরিন তাবাসসুম', 2018, 'হাসান খান', 'B-', 'photos/1.jpg', 'XL', '01555861250', 'imarula.ali@example.net', 'শিক্ষক', '২৫ করিমউদ্দিন তলী, উত্তরহাট বরিশাল', '২৩ করিমউদ্দিন ব্রীজ, নতুনখানা সিলেট', NULL, 'group', 3, 1, '1165.02', '01772421554', 'YG66AP13', 'bkash Agent', 'Cancel', '2025-07-16 04:30:39', '2025-07-16 04:30:39'),
(5, 'মিসেস. রহিমা আলী', 2006, 'মি. ইমরুল খান', 'O+', 'photos/2.jpg', 'L', '01643315603', 'tali@example.com', 'ইঞ্জিনিয়ার', '১ বরকত ব্রীজ, পোর্টটাউন ঢাকা', '৫৭ হাজী বাইপাস, পশ্চিমতলা সিলেট', 'রহমত খান', 'single', 3, 1, '1880.68', '01538032057', 'UW56MR00', 'bkash personal', 'Approved', '2025-07-16 04:30:39', '2025-07-16 04:30:39'),
(6, 'বরকত তাবাসসুম', 2004, 'রহিম খান', 'A+', 'photos/1.jpg', 'XL', '01692853396', 'ltabasasuma@example.org', 'সরকারি চাকরিজীবী', '১২ করিমউদ্দিন ক্যাম্প, নতুনখানা চিটাগং', '৩৫ বরকত বাইপাস, উত্তরটাউন সিলেট', 'মিসেস. জারিন তাবাসসুম', 'group', 5, 1, '1157.49', '01581334215', 'ZU06IY87', 'bkash Agent', 'Approved', '2025-07-16 04:30:39', '2025-07-16 04:30:39'),
(7, 'ফাহমেদা খান', 2016, 'মাসনুন তাসনীম', 'A+', 'photos/2.jpg', 'L', '01747702928', 'ctabasasuma@example.net', 'সরকারি চাকরিজীবী', '৮৭ করিমউদ্দিন বাইপাস, উত্তরহাট সিলেট', '৪৩ হাজী চিপা, পূর্বখানা কুমিল্লা', NULL, 'single', 4, 1, '691.89', '01697298811', 'YZ87TA83', 'bkash personal', 'Approved', '2025-07-16 04:30:40', '2025-07-16 04:30:40'),
(8, 'লাবনী আলী', 2015, 'বরকত তাসনীম', 'O-', 'photos/1.jpg', 'L', '01935429730', 'ananta49@example.com', 'শিক্ষক', '৮২ করিমউদ্দিন ক্যাম্প, পূর্বখানা চিটাগং', '৮০ বরকত বাইপাস, পশ্চিমটাউন বরিশাল', NULL, 'single', 2, 1, '1891.92', '01712296864', 'QM71AK57', 'bkash Agent', 'Approved', '2025-07-16 04:30:40', '2025-07-16 04:30:40'),
(9, 'সাবরিনা তাবাসসুম', 2006, 'জলিল তাবাসসুম', 'O-', 'photos/1.jpg', 'L', '01751592070', 'qtabasasuma@example.org', 'ডাক্তার', '৯১ করিমউদ্দিন বাইপাস, পশ্চিমহাট কুমিল্লা', '১২ বরকত চিপা, নতুনটাউন রাজশাহী', NULL, 'single', 1, 1, '1017.61', '01972155355', 'KS60DA74', 'bkash personal', 'Cancel', '2025-07-16 04:30:40', '2025-07-16 04:30:40'),
(10, 'ইমরুল আলী', 2011, 'মি. হাসনাত আলী', 'O+', 'photos/1.jpg', 'L', '01790307782', 'khana.jalila@example.org', 'সরকারি চাকরিজীবী', '৭৫ করিমউদ্দিন ক্যাম্প, নতুনতলা রাজশাহী', '৭০ হাজী সড়ক, উত্তরতলা খুলনা', NULL, 'single', 2, 1, '564.84', '01952681777', 'ZH34ZM03', 'bkash personal', 'Approved', '2025-07-16 04:30:40', '2025-07-16 04:30:40');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tokens`
--

CREATE TABLE `tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `registration_id` bigint UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_guest` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'info@reunion.com', NULL, '$2y$12$vqKO3piIJfo1otvJ8nRlS.rRKM48NPQ4vg2w1RFf0YH/nGtFHVo7C', NULL, '2025-07-15 06:12:21', '2025-07-15 06:12:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_categories`
--
ALTER TABLE `blog_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payments_registration_id_foreign` (`registration_id`);

--
-- Indexes for table `registrations`
--
ALTER TABLE `registrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `tokens`
--
ALTER TABLE `tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tokens_code_unique` (`code`),
  ADD KEY `tokens_registration_id_foreign` (`registration_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blog_categories`
--
ALTER TABLE `blog_categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `registrations`
--
ALTER TABLE `registrations`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tokens`
--
ALTER TABLE `tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_registration_id_foreign` FOREIGN KEY (`registration_id`) REFERENCES `registrations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tokens`
--
ALTER TABLE `tokens`
  ADD CONSTRAINT `tokens_registration_id_foreign` FOREIGN KEY (`registration_id`) REFERENCES `registrations` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
