<?php
    $setting = \App\Models\SiteSetting::first();

    // Use values from DB or fallback default
    $metaTitle =
        $setting && $setting->meta_title
            ? $setting->meta_title
            : 'ছাতার পাইয়া বহুমুখী উচ্চ বিদ্যালয় - পুনর্মিলনী ২০২৬';
    $metaDescription =
        $setting && $setting->meta_description ? $setting->meta_description : 'Default description here...';
    $favicon = $setting && $setting->favicon ? asset($setting->favicon) : asset('assets/logo.png');
    $logo = $setting && $setting->logo ? asset($setting->logo) : asset('assets/logo.png');
?>
<!DOCTYPE html>
<html lang="en" :class="{ 'theme-dark': dark }">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favicon -->
    <link rel="icon" href="<?php echo e($favicon); ?>" type="image/png">
    <!-- Dynamic Title -->
    <title><?php echo e($metaTitle); ?></title>
    <!-- Dynamic Meta Description -->
    <meta name="description" content="<?php echo e($metaDescription); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/tailwind.output.css')); ?>" />
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/datatables/datatables.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/datatables/buttons.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/datatables/responsive.css')); ?>" />
    <!-- Other CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/Chart.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/fontawesome/all.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/styles.css')); ?>">

    <!-- Summernote CSS -->
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet" />

    <!-- Alpine.js x-cloak global style -->
    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>
</head>

<body>
    
    <div x-data="data()" class="flex h-screen bg-gray-50" :class="{ 'overflow-hidden': isSideMenuOpen }">

        
        <aside class="main-sidebar">
            <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </aside>

        
        <div class="flex flex-col flex-1 w-full">
            <?php echo $__env->make('layouts.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <!-- JS Libraries -->

    <!-- jQuery (required for Summernote) -->
    <script src="<?php echo e(asset('assets/js/jquery-3.7.0.min.js')); ?>"></script>

    <!-- FontAwesome -->
    <script src="<?php echo e(asset('assets/fontawesome/all.min.js')); ?>"></script>

    <!-- DataTables JS -->
    <script src="<?php echo e(asset('assets/js/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatables/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatables/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datatables/custom.js')); ?>"></script>

    <!-- Chart.js -->
    <script src="<?php echo e(asset('assets/js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/charts-lines.js')); ?>" defer></script>
    <script src="<?php echo e(asset('assets/js/charts-pie.js')); ?>" defer></script>

    <!-- Summernote JS -->
    <script src="<?php echo e(asset('assets/js/summernote-lite.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/alpine.js')); ?>" defer></script>

    <!-- Your custom Alpine init -->
    <script src="<?php echo e(asset('assets/js/init-alpine.js')); ?>"></script>


    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\wamp64\www\reunioncp\resources\views/layouts/apps.blade.php ENDPATH**/ ?>