

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-6">
        <h2 class="my-6 text-2xl font-semibold text-gray-700">
            Site Settings
        </h2>

        <?php if(session('success')): ?>
            <div class="bg-green-200 p-3 rounded mb-4 text-green-800">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('site-settings.update')); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div>
                <label for="meta_title" class="block font-semibold">Meta Title</label>
                <input type="text" name="meta_title" id="meta_title"
                    value="<?php echo e(old('meta_title', $setting->meta_title ?? '')); ?>" class="border p-2 w-full" />
                <?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="meta_description" class="block font-semibold">Meta Description</label>
                <textarea name="meta_description" id="meta_description" rows="3" class="border p-2 w-full"><?php echo e(old('meta_description', $setting->meta_description ?? '')); ?></textarea>
                <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="favicon" class="block font-semibold">Favicon (PNG, ICO)</label>
                <input type="file" name="favicon" id="favicon" accept=".png,.ico" />
                <?php $__errorArgs = ['favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <?php if(!empty($setting->favicon)): ?>
                    <img src="<?php echo e(asset($setting->favicon)); ?>" alt="Favicon" class="w-12 h-12 mt-2" />
                <?php endif; ?>
            </div>

            <div>
                <label for="logo" class="block font-semibold">Logo (PNG, JPG)</label>
                <input type="file" name="logo" id="logo" accept=".png,.jpg,.jpeg" />
                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <?php if(!empty($setting->logo)): ?>
                    <img src="<?php echo e(asset($setting->logo)); ?>" alt="Logo" class="w-32 h-32 mt-2 rounded shadow" />
                <?php endif; ?>
            </div>

            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Save Changes</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apps', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\reunioncp\resources\views/pages/admin/site_settings/edit.blade.php ENDPATH**/ ?>