

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-6">
        <h3 class="text-xl font-bold mt-10 mb-4">Hero Section Content</h3>

        <?php if(session('success')): ?>
            <div class="p-3 mb-4 bg-green-100 text-green-700 rounded"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="mb-4 p-3 bg-red-100 text-red-700 rounded">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>- <?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('hero-section.update')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div>
                <label for="title" class="block font-semibold">Hero Title</label>
                <input type="text" name="title" id="title" value="<?php echo e(old('title', $hero->title ?? '')); ?>"
                    class="border p-2 w-full" />
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="subtitle" class="block font-semibold">Hero Subtitle</label>
                <textarea name="subtitle" id="subtitle" rows="2" class="border p-2 w-full"><?php echo e(old('subtitle', $hero->subtitle ?? '')); ?></textarea>
                <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="highlight" class="block font-semibold">Hero Highlight</label>
                <input type="text" name="highlight" id="highlight" value="<?php echo e(old('highlight', $hero->highlight ?? '')); ?>"
                    class="border p-2 w-full" />
                <?php $__errorArgs = ['highlight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                <div>
                    <label for="register_button_text" class="block font-semibold">Register Button Text</label>
                    <input type="text" name="register_button_text" id="register_button_text"
                        value="<?php echo e(old('register_button_text', $hero->register_button_text ?? '')); ?>"
                        class="border p-2 w-full" />
                    <?php $__errorArgs = ['register_button_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="register_button_url" class="block font-semibold">Register Button URL</label>
                    <input type="text" name="register_button_url" id="register_button_url"
                        value="<?php echo e(old('register_button_url', $hero->register_button_url ?? '')); ?>"
                        class="border p-2 w-full" />
                    <?php $__errorArgs = ['register_button_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="announcement_button_text" class="block font-semibold">Announcement Button Text</label>
                    <input type="text" name="announcement_button_text" id="announcement_button_text"
                        value="<?php echo e(old('announcement_button_text', $hero->announcement_button_text ?? '')); ?>"
                        class="border p-2 w-full" />
                    <?php $__errorArgs = ['announcement_button_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="announcement_button_url" class="block font-semibold">Announcement Button URL</label>
                    <input type="text" name="announcement_button_url" id="announcement_button_url"
                        value="<?php echo e(old('announcement_button_url', $hero->announcement_button_url ?? '')); ?>"
                        class="border p-2 w-full" />
                    <?php $__errorArgs = ['announcement_button_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="mt-6">
                <label for="background_image" class="block font-semibold">Hero Background Image</label>
                <input type="file" name="background_image" id="background_image" class="border p-2 w-full" />
                <?php $__errorArgs = ['background_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <?php if(!empty($hero->background_image)): ?>
                    <div class="mt-2">
                        <img src="<?php echo e(asset($hero->background_image)); ?>" class="w-32 rounded shadow"
                            alt="Hero Background" />
                    </div>
                <?php endif; ?>
            </div>
            <button type="submit" class="mt-4 bg-blue-600 text-white px-4 py-2 rounded">Save Changes</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apps', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\reunioncp\resources\views/pages/admin/hero_section/edit.blade.php ENDPATH**/ ?>